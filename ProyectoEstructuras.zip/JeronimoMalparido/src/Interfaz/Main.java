package Interfaz;

import controlador.GestorSolicitudes;
import mundo.Solicitud;

public class Main {
    public static void main(String[] args) {
        GestorSolicitudes gestor = new GestorSolicitudes();

        // Ejemplo: Registro de solicitudes
        gestor.registrarSolicitud(new Solicitud("Bogotá", "Medellín", 2000, 10));
        gestor.registrarSolicitud(new Solicitud("Bogotá", "Cali", 5000, 20));
        gestor.registrarSolicitud(new Solicitud("Medellín", "Cali", 3000, 15));

        // Procesar y mostrar las solicitudes en orden de prioridad
        System.out.println("Procesando solicitudes en orden de prioridad:");
        gestor.procesarSolicitudes();
    }
}
