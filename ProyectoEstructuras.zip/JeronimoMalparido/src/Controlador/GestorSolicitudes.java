package controlador;

import mundo.PriorityQueue;
import mundo.Solicitud;

public class GestorSolicitudes {
    private PriorityQueue<Solicitud> solicitudes;

    public GestorSolicitudes() {
        solicitudes = new PriorityQueue<>();
    }

    public void registrarSolicitud(Solicitud solicitud) {
        solicitudes.add(solicitud);
        System.out.println("Solicitud registrada: " + solicitud);
    }

    public void procesarSolicitudes() {
        while (!solicitudes.isEmpty()) {
            Solicitud solicitud = solicitudes.poll();
            System.out.println("Procesando: " + solicitud);
        }
    }
}
