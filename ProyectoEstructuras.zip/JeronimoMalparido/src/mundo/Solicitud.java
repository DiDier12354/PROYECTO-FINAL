package mundo;

public class Solicitud implements Comparable<Solicitud> {
    private String origen;
    private String destino;
    private int peso; // en kg
    private int volumen; // en m3

    public Solicitud(String origen, String destino, int peso, int volumen) {
        this.origen = origen;
        this.destino = destino;
        this.peso = peso;
        this.volumen = volumen;
    }

    public String getOrigen() {
        return origen;
    }

    public String getDestino() {
        return destino;
    }

    public int getPeso() {
        return peso;
    }

    public int getVolumen() {
        return volumen;
    }

    @Override
    public int compareTo(Solicitud o) {
        // Priorización por peso, luego por volumen
        if (this.peso != o.peso) {
            return o.peso - this.peso; // Descendente por peso
        }
        return this.volumen - o.volumen; // Ascendente por volumen
    }

    @Override
    public String toString() {
        return "Solicitud{" +
                "origen='" + origen + '\'' +
                ", destino='" + destino + '\'' +
                ", peso=" + peso +
                ", volumen=" + volumen +
                '}';
    }
}
