package mundo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class PriorityQueue<T extends Comparable<T>> {
    private List<T> elements;

    // Constructor sin recursión infinita
    public PriorityQueue() {
        this.elements = new ArrayList<>();
    }

    public void add(T element) {
        elements.add(element);
        Collections.sort(elements); // Ordena los elementos en base a su prioridad.
    }

    public T poll() {
        if (!elements.isEmpty()) {
            return elements.remove(0); // Devuelve y elimina el elemento de mayor prioridad.
        }
        return null;
    }

    public boolean isEmpty() {
        return elements.isEmpty();
    }
}
